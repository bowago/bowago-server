const router = require('express').Router();
const pricingController = require('../controllers/pricing.controller');
const { authenticate, requireLogisticsOrAbove, requireSuperAdmin } = require('../middleware/auth');
const { uploadImport } = require('../config/cloudinary');

/**
 * @swagger
 * tags:
 *   name: Pricing
 *   description: Quote calculator, cities, box dimensions, price bands, zone matrix, Excel import, rollback
 */

// ─── PUBLIC ───────────────────────────────────────────────────────────────────

/**
 * @swagger
 * /pricing/quote:
 *   post:
 *     summary: Calculate a shipping cost quote
 *     tags: [Pricing]
 *     security: []
 *     description: >
 *       Calculates the full shipping cost including surcharges.
 *       Sprint 2 — Pricing priority is automatically applied:
 *       1. Individual Contract Rate (enterprise clients — lowest price)
 *       2. Promo Code (discounted rate for promo users)
 *       3. Standard Rate (base price band for all other users)
 *
 *       For authenticated users, the JWT is read and their contract rate (if any)
 *       is applied automatically — no extra param needed.
 *       For guests (no JWT), always returns standard rate.
 *       Pass promoCode in body to apply a promotional discount (only for non-contract users).
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [fromCity, toCity]
 *             properties:
 *               fromCity: { type: string, example: "Lagos Cit" }
 *               toCity: { type: string, example: "Aba" }
 *               weightKg: { type: number, example: 150 }
 *               tons: { type: number, example: 0.15 }
 *               cartons: { type: integer, example: 5 }
 *               boxDimensionId: { type: string, format: uuid }
 *               customLength: { type: number, example: 60 }
 *               customWidth: { type: number, example: 40 }
 *               customHeight: { type: number, example: 30 }
 *               serviceType:
 *                 type: string
 *                 enum: [EXPRESS, STANDARD, ECONOMY]
 *                 default: STANDARD
 *               isFragile: { type: boolean, default: false }
 *               requiresInsurance: { type: boolean, default: false }
 *               insuranceValue: { type: number, example: 500000 }
 *               promoCode:
 *                 type: string
 *                 example: WELCOME20
 *                 description: "Optional - applies discount if valid and user has no contract rate"
 *     responses:
 *       200:
 *         description: Quote calculated with full surcharge breakdown and discount info
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 data:
 *                   type: object
 *                   properties:
 *                     quote:
 *                       type: object
 *                       properties:
 *                         zone: { type: integer, example: 2 }
 *                         distanceKm: { type: number, example: 464 }
 *                         weightKg: { type: number, example: 150 }
 *                         breakdown:
 *                           type: object
 *                           properties:
 *                             standardBasePrice: { type: number, example: 27000, description: "What a guest pays" }
 *                             finalBasePrice: { type: number, example: 22950, description: "After contract/promo discount" }
 *                         pricingMode:
 *                           type: string
 *                           enum: [STANDARD, CONTRACT, PROMO]
 *                           description: "STANDARD = guest rate, CONTRACT = enterprise, PROMO = promo code applied"
 *                         appliedDiscount:
 *                           type: object
 *                           nullable: true
 *                           description: "null for guests. Shows discount type, label, and amount for enterprise/promo users."
 *                           properties:
 *                             type: { type: string, example: CONTRACT_PERCENT }
 *                             label: { type: string, example: "Enterprise Discount — Dangote Group (15% off)" }
 *                             originalPrice: { type: number, example: 27000 }
 *                             discountAmount: { type: number, example: 4050 }
 *                             discountPercent: { type: number, example: 15 }
 *                         surchargeBreakdown:
 *                           type: array
 *                           items:
 *                             type: object
 *                             properties:
 *                               type: { type: string, example: FUEL }
 *                               label: { type: string, example: "Fuel Surcharge" }
 *                               description: { type: string, example: "Adjusted weekly based on market prices" }
 *                               amount: { type: number, example: 1262 }
 *                         totalSurcharge: { type: number, example: 2295 }
 *                         total: { type: number, example: 25245 }
 *                         currency: { type: string, example: NGN }
 *       400:
 *         description: City not found, no pricing for route, invalid promo code, weight missing
 */
router.post('/quote', authenticate, pricingController.getQuote);
// Note: authenticate here is optional (uses req.user?.id) — unauthenticated requests still work

/**
 * @swagger
 * /pricing/cities:
 *   get:
 *     summary: List all available cities
 *     tags: [Pricing]
 *     security: []
 *     parameters:
 *       - in: query
 *         name: region
 *         schema: { type: string }
 *         example: "South West"
 *       - in: query
 *         name: state
 *         schema: { type: string }
 *         example: Lagos
 *       - in: query
 *         name: search
 *         schema: { type: string }
 *     responses:
 *       200:
 *         description: Cities returned
 */
router.get('/cities', pricingController.listCities);

/**
 * @swagger
 * /pricing/dimensions:
 *   get:
 *     summary: List box dimension types
 *     tags: [Pricing]
 *     security: []
 *     responses:
 *       200:
 *         description: Box dimensions returned
 */
router.get('/dimensions', pricingController.listDimensions);

/**
 * @swagger
 * /pricing/price-bands:
 *   get:
 *     summary: List price bands
 *     tags: [Pricing]
 *     security: []
 *     parameters:
 *       - in: query
 *         name: zone
 *         schema: { type: integer }
 *       - in: query
 *         name: serviceType
 *         schema: { type: string, enum: [EXPRESS, STANDARD, ECONOMY] }
 *     responses:
 *       200:
 *         description: Price bands returned
 */
router.get('/price-bands', pricingController.listPriceBands);

/**
 * @swagger
 * /pricing/zone-matrix:
 *   get:
 *     summary: List zone matrix entries (Admin)
 *     tags: [Pricing]
 *     parameters:
 *       - in: query
 *         name: fromCity
 *         schema: { type: string }
 *       - in: query
 *         name: toCity
 *         schema: { type: string }
 *       - in: query
 *         name: page
 *         schema: { type: integer, default: 1 }
 *     responses:
 *       200:
 *         description: Zone matrix entries returned
 */
router.get('/zone-matrix', requireLogisticsOrAbove, pricingController.getZoneMatrix);

// ─── Admin: Manage pricing data ───────────────────────────────────────────────
router.use(authenticate, requireLogisticsOrAbove);

/**
 * @swagger
 * /pricing/cities:
 *   post:
 *     summary: Add or update a city (Admin)
 *     tags: [Pricing]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [name, region, state]
 *             properties:
 *               name: { type: string, example: "Lagos Cit" }
 *               region: { type: string, example: "South West" }
 *               state: { type: string, example: Lagos }
 *     responses:
 *       201:
 *         description: City saved
 */
router.post('/cities', pricingController.upsertCity);

/**
 * @swagger
 * /pricing/cities/{id}:
 *   delete:
 *     summary: Delete a city (Super Admin)
 *     tags: [Pricing]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string, format: uuid }
 *     responses:
 *       200:
 *         description: City deleted
 */
router.delete('/cities/:id', requireSuperAdmin, pricingController.deleteCity);

/**
 * @swagger
 * /pricing/dimensions:
 *   post:
 *     summary: Add or update a box dimension (Admin)
 *     tags: [Pricing]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [categoryId, displayName, lengthCm, widthCm, heightCm, weightKgLimit]
 *             properties:
 *               categoryId: { type: string, example: "S-01" }
 *               displayName: { type: string, example: "Small Box" }
 *               lengthCm: { type: number, example: 30 }
 *               widthCm: { type: number, example: 22 }
 *               heightCm: { type: number, example: 22 }
 *               bestFor: { type: string, example: "Books/Tools" }
 *               weightKgLimit: { type: number, example: 10 }
 *     responses:
 *       201:
 *         description: Dimension saved
 */
router.post('/dimensions', pricingController.upsertDimension);
router.delete('/dimensions/:id', pricingController.deleteDimension);

/**
 * @swagger
 * /pricing/price-bands:
 *   post:
 *     summary: Create price band (Admin)
 *     tags: [Pricing]
 *     description: All changes are logged to the price audit trail automatically.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [zone, minKg, minTons, minCartons]
 *             properties:
 *               zone: { type: integer, example: 2 }
 *               serviceType: { type: string, enum: [EXPRESS, STANDARD, ECONOMY], default: STANDARD }
 *               minKg: { type: number, example: 50 }
 *               maxKg: { type: number, example: 200, nullable: true }
 *               pricePerKg: { type: number, example: 180 }
 *               basePrice: { type: number, example: 9000 }
 *               minTons: { type: number, example: 0.05 }
 *               minCartons: { type: integer, example: 2 }
 *     responses:
 *       201:
 *         description: Price band created and logged to audit trail
 */
router.post('/price-bands', pricingController.createPriceBand);

/**
 * @swagger
 * /pricing/price-bands/{id}:
 *   put:
 *     summary: Update price band (Admin)
 *     tags: [Pricing]
 *     description: Changes are logged to the price audit trail. Use /pricing/price-bands/{id}/rollback to revert.
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string, format: uuid }
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               pricePerKg: { type: number }
 *               basePrice: { type: number }
 *               isActive: { type: boolean }
 *               reason: { type: string, description: "Reason stored in audit log" }
 *     responses:
 *       200:
 *         description: Updated and logged
 */
router.put('/price-bands/:id', pricingController.updatePriceBand);

/**
 * @swagger
 * /pricing/price-bands/{id}:
 *   delete:
 *     summary: Delete price band (Admin)
 *     tags: [Pricing]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string, format: uuid }
 *     responses:
 *       200:
 *         description: Deleted
 */
router.delete('/price-bands/:id', pricingController.deletePriceBand);

/**
 * @swagger
 * /pricing/price-bands/rollback/{auditLogId}:
 *   post:
 *     summary: Rollback a price band to its previous value (Super Admin)
 *     tags: [Pricing]
 *     description: >
 *       Sprint 8 — Instantly reverts a price band to its previous value using the audit log entry.
 *       Get audit log IDs from GET /surcharges/audit-log.
 *       The rollback itself is also logged to the audit trail.
 *       Use this when a surcharge error is detected and pricing needs to be restored immediately.
 *     parameters:
 *       - in: path
 *         name: auditLogId
 *         required: true
 *         schema: { type: string, format: uuid }
 *         description: The audit log entry ID to roll back to
 *     responses:
 *       200:
 *         description: Price band rolled back successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 data:
 *                   type: object
 *                   properties:
 *                     band:
 *                       $ref: '#/components/schemas/PriceBand'
 *       400:
 *         description: No previous value to roll back to, or not a PriceBand entry
 *       404:
 *         description: Audit log entry not found
 */
router.post('/price-bands/rollback/:auditLogId', requireSuperAdmin, pricingController.rollbackPriceBand);

/**
 * @swagger
 * /pricing/zone-matrix:
 *   post:
 *     summary: Add or update zone matrix entry (Admin)
 *     tags: [Pricing]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [fromCityId, toCityId, zone]
 *             properties:
 *               fromCityId: { type: string, format: uuid }
 *               toCityId: { type: string, format: uuid }
 *               zone: { type: integer, example: 2 }
 *     responses:
 *       201:
 *         description: Zone matrix updated
 */
router.post('/zone-matrix', pricingController.upsertZoneMatrix);

/**
 * @swagger
 * /pricing/import:
 *   post:
 *     summary: Bulk import pricing data from Excel (Admin)
 *     tags: [Pricing]
 *     description: >
 *       Imports cities, zone matrix, KM distances, and box dimensions from the
 *       Rating_For_BowaGO.xlsx file. Expects sheets named:
 *       Zone Matrix, Matrix by KM, Dimensions, Zone Matrix by Region.
 *       All records are upserted — safe to re-run.
 *     requestBody:
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               file:
 *                 type: string
 *                 format: binary
 *     responses:
 *       200:
 *         description: Import completed
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 data:
 *                   type: object
 *                   properties:
 *                     results:
 *                       type: object
 *                       properties:
 *                         cities: { type: integer }
 *                         zones: { type: integer }
 *                         km: { type: integer }
 *                         dimensions: { type: integer }
 *                         errors: { type: array, items: { type: string } }
 */
router.post('/import', uploadImport.single('file'), pricingController.importPricingSheet);

module.exports = router;
